/*************************************************************************
	> File Name: server.c
	> Author:UgoLi 
	> Mail: 2653920896@qq.com
	> Created Time: 2017年07月19日 星期三 10时22分41秒
 ************************************************************************/
#ifndef _T__NET_H
#define _T__NET_H
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<unistd.h>
#include<ctype.h>
#include<arpa/inet.h>
typedef struct sockaddr_in SA_I;
typedef struct sockaddr  SA;

#endif //_T__NET_H


